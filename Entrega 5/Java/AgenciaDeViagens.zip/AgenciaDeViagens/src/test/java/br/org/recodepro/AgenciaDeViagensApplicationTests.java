package br.org.recodepro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenciaDeViagensApplicationTests {

	@Test
	void contextLoads() {
	}

}
